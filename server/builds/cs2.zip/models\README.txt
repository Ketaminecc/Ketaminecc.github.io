ketamine.cc playermodels
=======================

Drop model files in this folder. They show up in the model picker on the
ESP preview window and in Visual -> Players -> playermodel, and the selected
one is what the world overlay draws on players.

FORMAT: Wavefront .obj  (file extension .obj)

Requirements
------------
* One object. "v x y z" positions and "f ..." faces.
* Faces may be triangles or quads. The usual index forms work:
      f 1 2 3
      f 1/1 2/2 3/3
      f 1//1 2//2 3//3
* Units are metres, Y is up, the model should face -Z.
  The loader re-centres the model and scales it to 1.7 m tall, so the export
  size does not matter. A Z-up export (Blender's default) is rotated upright
  automatically when the Z span is clearly larger than the Y span.
* Optional flat tint, anywhere in the file as a comment:
      # color C81E28
  Used when the model has no texture.

TEXTURES
--------
Put the texture png in this folder next to the model. It is matched by name:
any png whose filename contains the model's base name, case-insensitive.

    TripleT.obj  ->  TripleT-Textures.png
    Trump.obj    ->  TrumpTextures.png

The preview samples it per pixel, so a textured model shows its real skin in
the ESP preview. The world overlay draws flat-shaded triangles through ImGui
and cannot sample a texture; it keeps the per-face light shading.

UVs are taken from the .obj ("vt" entries and the middle index of each face).
When they are present the texture is placed exactly as the artist unwrapped it
and nothing needs tuning.

If the export contains NO UVs (both of the current models are UV-less) the
atlas cannot be placed correctly by any code, so the default is deliberate:
the model is drawn as a flat tint (its "# color", or the accent) and the
texture is ignored. In Visual -> Players -> playermodel, "wrap guess (no uvs)"
turns on a best-effort fallback instead: the mesh is wrapped once around a
vertical cylinder (u from the angle around the body, v from its height) so
neighbouring faces sample neighbouring texels and the sheet flows around the
model. "tex repeat" and "tex shift" align it by hand. That is an approximation,
not a real unwrap - export with UVs (Blender: Export > Wavefront .obj with
"UVs" enabled) for the exact skin.

FACE BUDGET
-----------
The preview is a CPU rasterizer, so each model keeps at most 40,000 faces in
its render list; past that the smallest faces by area are dropped, largest
first, which preserves the silhouette. Meshes above 12,000 faces are rendered
without 2x supersampling, which is a 4x cut in pixel work, and the preview
redraws at most 30 times a second and reuses the previous image in between, so
a dense model cannot drag the menu's framerate down. The world overlay draws at
most 6,000 of the model's faces through ImGui and skips the whole mesh when the
body is off screen.
